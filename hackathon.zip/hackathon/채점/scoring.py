import google.generativeai as genai
import json
import os
import fitz  # PyMuPDF (PDF 처리용)
import PIL.Image # 이미지 처리용

# ---------------------------------------------------------
# [설정] 구글 API 키 입력
# (사용자님이 공유해주신 키를 적용했습니다. 나중에 꼭 재발급 받으세요!)
# ---------------------------------------------------------
GOOGLE_API_KEY = "AIzaSyDhOqiV35t6pPCNOvmWBTHUY6mJZrLcC90"

# API 키 설정
genai.configure(api_key=GOOGLE_API_KEY)

def extract_text_from_pdf(pdf_path):
    """PDF 파일에서 텍스트 추출"""
    if not os.path.exists(pdf_path):
        return None
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text() + "\n"
    return text

def grade_exam_gemini(pdf_path, image_path):
    # ---------------------------------------------------------
    # [수정됨] 모델 이름을 사용 가능한 'gemini-2.0-flash'로 변경했습니다.
    # ---------------------------------------------------------
    model = genai.GenerativeModel('gemini-2.0-flash')

    # 2. 파일 읽기
    print(f"📂 파일 읽는 중... 기준표:[{pdf_path}], 시험지:[{image_path}]")
    
    rubric_text = extract_text_from_pdf(pdf_path)
    if not rubric_text: return json.dumps({"error": f"PDF 파일을 찾을 수 없습니다: {pdf_path}"})

    if not os.path.exists(image_path):
        return json.dumps({"error": f"이미지 파일을 찾을 수 없습니다: {image_path}"})
    
    # Gemini는 이미지를 파일 경로로 여는 대신 PIL 객체로 넘기면 됩니다.
    exam_image = PIL.Image.open(image_path)

    # 3. 프롬프트 작성
    prompt_text = f"""
    당신은 선형대수학 전공 과목의 꼼꼼하고 공정한 AI 조교입니다.
    
    [입력 데이터]
    1. 채점 기준표(Rubric):
    ---------------------------------------------------
    {rubric_text}
    ---------------------------------------------------
    
    [지시 사항]
    STEP 0. **기존 채점 무시:** 이미지에 이미 빨간색 펜으로 적힌 점수나 표시는 무시하세요. 백지 상태에서 새로 채점합니다.
    STEP 1. **답안 판독:** 학생의 손글씨 답안(행렬, 수식 등)을 판독하세요.
    STEP 2. **검토 필요 여부(Guardrail):** 글씨가 너무 뭉개지거나 답안이 비어있다면 검토를 요청하세요.
    STEP 3. **채점:** 검토가 필요 없다면, 기준표에 따라 점수를 매기세요.

    [출력 포맷 (JSON)]
    반드시 아래 JSON 형식으로만 응답하세요. (Markdown 코드블록 없이 Plain Text로 JSON만 출력)
    {{
        "needs_review": true 또는 false,
        "review_reason": "검토가 필요한 경우 사유",
        "student_handwriting": "판독된 답안 내용 요약",
        "score": 점수 (숫자),
        "feedback": "상세 피드백 (감점 사유 등)"
    }}
    """

    # 4. Gemini 호출
    try:
        print("🤖 Gemini 2.0이 채점을 진행 중입니다... (모델 업데이트 완료)")
        response = model.generate_content([prompt_text, exam_image])
        
        # 결과 텍스트 정리
        result_text = response.text.replace("```json", "").replace("```", "").strip()
        return result_text

    except Exception as e:
        return json.dumps({"error": str(e)})

# ---------------------------------------------------------
# [실행 부분]
# ---------------------------------------------------------
if __name__ == "__main__":
    # 파일명을 본인 파일명과 똑같이 수정하세요
    RUBRIC_FILE = "채점기준표.pdf" 
    EXAM_FILE = "시험지.jpg"

    result_json = grade_exam_gemini(RUBRIC_FILE, EXAM_FILE)
    
    # 결과 파싱
    try:
        result = json.loads(result_json)
        
        if "error" in result:
            print(f"❌ 오류 발생: {result['error']}")
        else:
            print("\n" + "="*40)
            if result.get('needs_review'):
                print("🚩 [검토 필요] 교수님의 확인이 필요합니다!")
                print(f"   - 사유: {result.get('review_reason')}")
            else:
                print("✅ [채점 완료]")
                print(f"   - 점수: {result.get('score')}점")
            
            print("-" * 40)
            print(f"✍️ [답안 판독]\n{result.get('student_handwriting')}")
            print("-" * 40)
            print(f"🗣️ [피드백]\n{result.get('feedback')}")
            print("="*40)
            
    except json.JSONDecodeError:
        print("❌ JSON 파싱 실패. 원본 응답:\n", result_json)