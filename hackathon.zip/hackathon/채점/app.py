from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import uuid
# 기존에 작성한 채점 로직 가져오기
from scoring import grade_exam_gemini
import json

app = Flask(__name__)
CORS(app)  # 프론트엔드에서 서버로 접속 허용

# 업로드된 파일을 잠시 저장할 폴더
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        # 1. 파일 받기
        if 'exam' not in request.files or 'rubric' not in request.files:
            return jsonify({"error": "파일이 누락되었습니다."}), 400

        exam_file = request.files['exam']
        rubric_file = request.files['rubric']

        # 2. 파일명 안전하게 저장 (중복 방지 위해 UUID 사용)
        exam_filename = f"{uuid.uuid4()}.jpg"
        rubric_filename = f"{uuid.uuid4()}.pdf"
        
        exam_path = os.path.join(UPLOAD_FOLDER, exam_filename)
        rubric_path = os.path.join(UPLOAD_FOLDER, rubric_filename)

        exam_file.save(exam_path)
        rubric_file.save(rubric_path)

        # 3. Gemini 채점 로직 실행
        # (scoring_gemini.py의 함수 호출)
        print("🤖 분석 시작...")
        result_json_str = grade_exam_gemini(rubric_path, exam_path)
        
        # 4. 결과 파싱 (문자열 -> JSON 객체)
        # Gemini가 가끔 마크다운 블록을 포함할 수 있어 한 번 더 처리
        clean_json_str = result_json_str.replace("```json", "").replace("```", "").strip()
        result_data = json.loads(clean_json_str)

        # 5. 임시 파일 삭제 (선택 사항)
        os.remove(exam_path)
        os.remove(rubric_path)

        return jsonify(result_data)

    except Exception as e:
        print(f"❌ 서버 에러: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("🚀 채점 서버가 실행되었습니다: http://127.0.0.1:5000")
    app.run(debug=True, port=5000)