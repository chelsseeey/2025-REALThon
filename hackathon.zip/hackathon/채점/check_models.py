import google.generativeai as genai
import os

# ---------------------------------------------------------
# [설정] 사용 중인 구글 API 키를 넣어주세요
# ---------------------------------------------------------
GOOGLE_API_KEY = "AIzaSyBfLYsSExoBF6SY-oAtQrcL47FxyhK6P5A" # 본인의 키로 변경

genai.configure(api_key=GOOGLE_API_KEY)

print("🔍 내 API 키로 사용 가능한 모델 목록을 조회합니다...\n")

try:
    count = 0
    for m in genai.list_models():
        # 'generateContent' (텍스트/이미지 생성) 기능이 있는 모델만 출력
        if 'generateContent' in m.supported_generation_methods:
            print(f"- {m.name}")
            count += 1
    
    if count == 0:
        print("⚠️ 사용 가능한 모델이 하나도 없습니다. API 키 권한이나 지역 제한을 확인하세요.")
    else:
        print(f"\n✅ 총 {count}개의 모델이 확인되었습니다.")
        print("👉 위 목록 중 하나를 scoring.py의 모델 이름으로 복사해서 쓰세요.")

except Exception as e:
    print(f"❌ 오류 발생: {e}")