import sys
import os
import json
import argparse
import base64
import mimetypes
import numpy as np
import time
from openai import OpenAI

sys.stdout.reconfigure(encoding='utf-8')
# ==========================================
# 1. 설정 및 OpenAI 클라이언트 초기화
# ==========================================
# [주의] 여기에 실제 OpenAI API 키를 입력하거나 환경 변수를 설정하세요.
client = OpenAI(api_key="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") 

def encode_image(image_path):
    mime = mimetypes.guess_type(image_path)[0] or "image/png"
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"

# ==========================================
# 2. Score Parsing Logic
# ==========================================
def parse_score_table(image_path):
    image_data = encode_image(image_path)
    prompt = """
    이미지는 학생들의 점수표입니다. '학번'과 각 '문항'별 점수를 읽어서
    다음 JSON 형식의 리스트로 출력하세요.
    [
        { "student_id": "2024001", "scores": { "1": 10, "2": 15, "3": 20 } },
        ...
    ]
    오직 JSON만 출력하세요.
    """
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            response_format={"type": "json_object"},
            messages=[
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": image_data}}
                ]}
            ]
        )
        content = response.choices[0].message.content
        return json.loads(content)
    except Exception as e:
        return {"error": str(e)}

# ==========================================
# 3. Student Answer Parsing Logic
# ==========================================
def parse_student_answer(image_path, student_id="unknown"):
    image_data = encode_image(image_path)
    prompt = f"""
    학생({student_id})의 답안지입니다. 문항 번호, 하위 문항, 텍스트/수식을 파싱하여
    다음 스키마의 JSON으로 반환하세요.
    {{
      "exam_id": "{student_id}",
      "problems": [ {{ "problem_number": 1, "subparts": [...] }} ]
    }}
    """
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            response_format={"type": "json_object"},
            messages=[
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": image_data}}
                ]}
            ]
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        return {"exam_id": student_id, "error": str(e), "problems": []}

# ==========================================
# 4. Analysis & Mock Data Generation
# ==========================================
def perform_analysis(blank_path, rubric_path, score_path, student_paths):
    # 실제 데이터 처리 로직 (생략) ...
    
    # [수정됨] student_paths의 길이를 학생 수로 사용
    student_count = len(student_paths)
    
    # 로딩 시뮬레이션
    time.sleep(2)

    # 결과 생성 함수 호출
    return generate_mock_like_real_data(student_count) 

def generate_mock_like_real_data(student_count):
    # [수정 완료] 여기서 studentCount 대신 매개변수인 student_count를 사용합니다.
    
    return {
        "totalStudents": student_count,
        "questions": [
            {
                "qNum": 1,
                "maxScore": 10,
                "qText": "이차방정식 x² - 5x + 6 = 0 의 두 근을 구하고 과정을 서술하시오. (AI 분석 완료)",
                "avgScore": 8.2,
                "scoreLabels": ["0점", "1-3점", "4-6점", "7-9점", "10점"],
                # 점수 분포 데이터도 학생 수에 맞춰서 대략적으로 생성
                "scoreData": [1, 2, 3, 4, max(0, student_count - 10)],
                "clusters": [
                    {
                        "cluster_index": 1,
                        "cognitive_diagnosis": {
                            "misconceptions": ["인수분해 부호 실수 ((x+2)(x+3)으로 계산)"],
                            "logical_gaps": ["근의 공식 대입 시 분모 계산 오류"],
                            "missing_keywords": ["판별식"]
                        },
                        "pattern_characteristics": {
                            "specificity": "구체적",
                            "approach": "정석 풀이",
                            "error_type": "계산 실수 위주"
                        },
                        "quantitative_metrics": {
                            # [수정됨] student_count 사용
                            "num_students": int(student_count * 0.7),
                            "percentage": 70.0,
                            "relative_length": "평균 문자 수가 중간 정도",
                            "expected_score_level": "중~상"
                        },
                        "overall_summary": "이 클러스터의 학생들은 대체로 정석적인 풀이를 따랐으나, 부호나 단순 계산에서 실수가 발생했습니다."
                    },
                    {
                        "cluster_index": 2,
                        "cognitive_diagnosis": {
                            "misconceptions": ["근 판별법에 대한 이해 부족"],
                            "logical_gaps": ["풀이 과정 없이 답만 기재"],
                            "missing_keywords": ["인수분해", "근의 공식"]
                        },
                        "pattern_characteristics": {
                            "specificity": "낮음",
                            "approach": "직관적/암산",
                            "error_type": "개념 오류"
                        },
                        "quantitative_metrics": {
                            # [수정됨] student_count 사용
                            "num_students": int(student_count * 0.3),
                            "percentage": 30.0,
                            "relative_length": "짧음",
                            "expected_score_level": "하"
                        },
                        "overall_summary": "풀이 과정이 거의 없거나 개념적 이해가 부족하여 답을 도출하지 못한 유형입니다."
                    }
                ]
            }
            # 필요시 Q2, Q3 추가
        ]
    }

# ==========================================
# Main Orchestrator
# ==========================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--blank", required=True, help="문제 원본 PDF/IMG 경로")
    parser.add_argument("--rubric", required=True, help="채점 기준표 IMG 경로")
    parser.add_argument("--score", required=True, help="점수표 IMG 경로")
    parser.add_argument("--students", nargs='+', required=True, help="학생 답안 IMG 경로 리스트")
    args = parser.parse_args()

    try:
        # 분석 실행
        final_data = perform_analysis(args.blank, args.rubric, args.score, args.students)
        
        # 결과를 JSON 문자열로 출력 (Node.js가 읽는 부분)
        print(json.dumps(final_data, ensure_ascii=False))
        
    except Exception as e:
        # 에러 발생 시 stderr로 출력
        sys.stderr.write(f"Error in analysis_wrapper.py: {str(e)}")
        sys.exit(1)