const express = require("express");
const multer = require("multer");
const cors = require("cors");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

const app = express();
const port = 3000;

app.use(cors());

// [수정됨] CSP 보안 정책 완화 설정
app.use((req, res, next) => {
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; " +
      // 스크립트 허용: 로컬 파일, 인라인 스크립트, Tailwind CDN, Chart.js CDN, 외부 스크립트 실행 허용('unsafe-eval')
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.tailwindcss.com https://cdn.jsdelivr.net; " +
      // 스타일 허용: 로컬 파일, 인라인 스타일, FontAwesome, Google Fonts
      "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; " +
      // 이미지 허용: 로컬 파일, data URI(Base64 이미지), blob URL
      "img-src 'self' data: blob:; " +
      // 폰트 허용: Google Fonts
      "font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; " +
      // 연결 허용: 로컬 서버와의 API 통신 및 웹소켓(ws) 허용
      "connect-src 'self' http://localhost:3000 ws://localhost:3000;"
  );
  next();
});

app.use(express.static(path.join(__dirname, "../dashboard")));

// 루트 경로 접속 시 dashboard.html 제공
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../dashboard", "dashboard.html"));
});

// 업로드 폴더 생성
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + "-" + uniqueSuffix + ext);
  },
});

const upload = multer({ storage: storage });

// 임시 파일 경로 저장소
let tempFilePaths = {
  blankPath: null,
  rubricPath: null,
  scorePaths: [],
};

// ==========================================
// 1단계: 문제지, 기준표, 점수표 업로드
// ==========================================
const questionUpload = upload.fields([
  { name: "file", maxCount: 1 },
  { name: "rubric", maxCount: 1 },
  { name: "scoreFiles", maxCount: 50 },
]);

app.post("/question-papers/upload", questionUpload, (req, res) => {
  console.log("📥 [1단계] 문제지/점수표 업로드 수신");

  try {
    if (
      !req.files["file"] ||
      !req.files["rubric"] ||
      !req.files["scoreFiles"]
    ) {
      throw new Error("필수 파일이 누락되었습니다.");
    }

    tempFilePaths.blankPath = req.files["file"][0].path;
    tempFilePaths.rubricPath = req.files["rubric"][0].path;
    tempFilePaths.scorePaths = req.files["scoreFiles"].map((f) => f.path);

    res.status(200).json({ message: "Step 1 Upload Success" });
  } catch (e) {
    console.error("Step 1 Error:", e);
    res.status(500).json({ error: "파일 업로드 실패", details: e.message });
  }
});

// ==========================================
// 2단계: 답안지 업로드 및 분석 실행
// ==========================================
const answerUpload = upload.fields([{ name: "files", maxCount: 50 }]);

app.post("/answer-sheets/upload", answerUpload, (req, res) => {
  console.log("📥 [2단계] 답안지 수신 및 분석 시작...");

  // 1단계 파일 확인
  if (!tempFilePaths.blankPath || !tempFilePaths.rubricPath) {
    return res.status(400).json({
      error: "1단계 파일(문제지 등)이 없습니다. 새로고침 후 다시 시도해주세요.",
    });
  }

  try {
    const studentPaths = req.files["files"].map((f) => f.path);
    const scorePathArg = tempFilePaths.scorePaths[0];

    const args = [
      "analysis_wrapper.py",
      "--blank",
      tempFilePaths.blankPath,
      "--rubric",
      tempFilePaths.rubricPath,
      "--score",
      scorePathArg,
      "--students",
      ...studentPaths,
    ];

    console.log("🐍 Python 스크립트 실행 중...");
    const pythonProcess = spawn("python", args);

    let dataString = "";
    let errorString = "";

    pythonProcess.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorString += data.toString();
      console.log("PyLog:", data.toString());
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        return res
          .status(500)
          .json({ error: "분석 실패", details: errorString });
      }
      try {
        const resultJson = JSON.parse(dataString);
        res.json(resultJson);
      } catch (e) {
        console.error("JSON Parse Error:", e);
        res
          .status(500)
          .json({ error: "결과 데이터 파싱 오류", raw: dataString });
      }
    });
  } catch (e) {
    console.error("Server Error:", e);
    res.status(500).json({ error: "서버 내부 오류" });
  }
});

app.listen(port, () => {
  console.log(`=============================================`);
  console.log(`🚀 서버 실행 중! 아래 주소로 접속하세요:`);
  console.log(`👉 http://localhost:${port}`);
  console.log(`=============================================`);
});
